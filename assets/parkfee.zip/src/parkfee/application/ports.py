"""애플리케이션이 의존하는 저장소 인터페이스(Repository)."""

from __future__ import annotations

from typing import Protocol

from parkfee.domain.coupon import Coupon
from parkfee.domain.season_pass import SeasonPass


class SeasonPassRepository(Protocol):
    def find_by_plate(self, plate: str) -> list[SeasonPass]:
        """차량번호로 등록된 정기권을 모두 돌려준다."""
        ...


class CouponRepository(Protocol):
    def find(self, code: str) -> Coupon:
        """쿠폰을 찾는다. 없으면 CouponNotFoundError."""
        ...
